public enum MemorySegment {
    LOCAL,
    ARGUMENT,
    CONSTANT,
    STATIC,
    THIS,
    THAT,
    POINTER,
    TEMP
}
